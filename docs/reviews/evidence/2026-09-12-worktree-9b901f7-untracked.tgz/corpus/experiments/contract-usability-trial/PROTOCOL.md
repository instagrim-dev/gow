# Contract usability trial — can an unfamiliar reader execute the method?

**Status: `configured_not_executed`.** This is a preregistration. No trial has
been run. It fixes the design so that a later trial cannot silently change the
subject, the case, the instrument, or what counts as a finding.

It is the [book lane](../../../docs/book/README.md)'s gate **B4** and the method
contract's adoption gate **A3**
([`docs/book/method-contract.md` §8](../../../docs/book/method-contract.md#8-adoption-and-change-policy)).

## What this trial is and is not

This is a **usability and methodological test**, not a validation threshold.

| It can show | It cannot show |
|---|---|
| The instructions are not executable as written (specific step, specific confusion) | That the method's recommendations are correct |
| Two readers following R1–R6 produce descriptions that recommend incompatible actions | That map-guided work beats undirected work |
| A step's discretion is so wide that the reader's choice, not the method, determines the outcome | Discovery, transfer, or convergence |
| The contract's own failure modes occur in practice | Anything about a domain the trial did not touch |

A successful trial does not upgrade any instruction's authority tier. A failed
trial is direct evidence that the prose is defective, and the contract is
weakened or split accordingly.

## 1. Subject

One or more subjects satisfying **all** of:

- has **not** contributed to this repository and has not read the
  [theory series](../../../docs/theory/) or the manuscript;
- is a competent practitioner in the trial case's domain;
- is not walked through the case by the project author. The author may answer
  questions about *what an instruction means* — and every such question is
  recorded as a defect candidate, because a self-contained contract should not
  need them.

**Declared before the trial:** the number of subjects, and how they were found.
A single subject is a case study; it is reported as one.

## 2. Instrument

Supplied to the subject, and nothing else:

1. [`docs/book/method-contract.md`](../../../docs/book/method-contract.md) at the
   exact revision under test (record the revision and the commit).
2. [`docs/book/warrant-boundaries.md`](../../../docs/book/warrant-boundaries.md).
3. A blank record template derived from contract §3.

**Not supplied:** the theory series, the manuscript, the thesis guides, `newf`,
this repository, or any worked example from the project. If the subject needs
project context to proceed, that is the finding.

## 3. Case

An **uncurated** case: a real body of attempts on one objective, assembled by
someone other than the project author, without selecting attempts for how well
they suit the method.

Required properties (contract §1 preconditions P1–P4):

- three or more serious attempts on one stated objective;
- an outcome check the subject does not adjudicate by opinion;
- attempts materially more expensive than describing them;
- the possibility of recording a prediction before an outcome.

Explicitly **prohibited**: any case from `corpus/experiments/`, the
Erdős–Straus corpora, or the concurrency worked example in
[`docs/thesis/how-to-map-the-work.md`](../../../docs/thesis/how-to-map-the-work.md).
Those are curated by the project and would test recall, not usability.

**Declared before the trial:** the case, its provenance, who assembled it, and
why it satisfies P1–P4 — recorded in this directory before the subject sees it.

## 4. Procedure

1. Freeze the contract revision and record it here.
2. Record the case declaration (§3) before the subject is engaged.
3. The subject works the case using only the instrument, producing: the
   attempt records, at least two candidate descriptions (R4), the divergence
   case (R5), a predeclared prediction (A2), a chosen design with its
   justification (A1, A4), the outcome, and a stopping condition (§6).
4. Every question the subject asks is logged verbatim, with the step it
   concerns, before it is answered.
5. Every point where the subject's choice was unconstrained by the contract is
   logged as a **discretion site**.
6. The subject reports, in their own words: which step was hardest, which
   instruction they could not follow, and which one they ignored.
7. If two or more subjects worked the same case independently, compare the
   **actions their maps recommend** — not the vocabulary of their maps.

## 5. Recorded findings

Findings are recorded whatever they say. The trial has no pass condition,
because it is not a validation gate.

| Finding kind | Recorded as | Consequence for the contract |
|---|---|---|
| **Unexecutable instruction** | the step, the subject's words, what they did instead | Rewrite, weaken, or split the instruction |
| **Discretion site** | the choice the contract left open, and whether it changed the recommended action | Either narrow the instruction with a stated reason, or state the discretion explicitly in the text |
| **Divergent recommendation** (multi-subject) | the two maps and the two actions | Contract §3 does not yet constrain representation enough for this case class; record the class |
| **Context dependence** | the question that required project knowledge | The contract is not self-contained; gate A1 fails |
| **Observed failure mode** | which declared failure mode occurred | Keep; cite the trial in the book chapter that teaches the instruction |
| **Successful execution** | the artifacts produced | The instructions were followable *in this case*. Nothing more. |

## 6. Analysis limits

- No comparison arm. This trial does **not** compare the method against a
  practitioner working without it; that is the
  [superiority preregistration](../superiority-preregistration/PROTOCOL.md),
  which is separately unexecuted.
- No efficiency claim. If total cost is recorded, it is recorded per contract
  E5 (construction, analysis, interpretation, attention — not only the
  convenient unit) and reported as a description of this trial, not a rate.
- No attribution claim. If the subject's chosen action succeeds, the trial does
  not establish that the map produced the success
  ([warrant boundaries](../../../docs/book/warrant-boundaries.md)).
- The subject is not blinded to the fact that they are testing a method.
  Recorded as a limitation; the method's instructions are the object of study,
  so blinding is not available.

## 7. Freeze record

| Field | Value |
|---|---|
| Protocol frozen at | (commit to be recorded before execution) |
| Contract revision under test | v0.1.0 (`proposed`) |
| Subjects | not yet recruited |
| Case | not yet declared |
| Execution | **not executed** |
| Findings | none — no trial has been run |
